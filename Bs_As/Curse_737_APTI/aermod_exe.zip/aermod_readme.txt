 
                      AERMOD README (dated 14134)             05/14/2014

This file describes the components included in this release of the 
revised AERMOD model (dated 14134), which replaces the previous version 
of AERMOD dated 13350.  A list of modifications to the AERMOD model 
incorporated in this update is provided in the AERMOD Model Change 
Bulletin (MCB) #10.  Additional details regarding revisions to the
model are provided in the updated AERMOD User's Guide Addendum.


The following lists new or modified files associated with this update
to the AERMOD dispersion model. Note that the AERMOD test cases have
been updated with version 13350 given the range of modifications to 
the model. Also note that the meteorological data inputs for the AERMOD
test cases have also been updated given the range of modifications to the
AERMET meteorological processor.

FILENAME                DESCRIPTION
-------------------     -------------------------------------------------

aermod_readme.txt       This README file

aermod_mcb9.txt         AERMOD Model Change Bulletin (MCB) #10

aermod_exe.zip          AERMOD executable, compiled with the Intel Visual
                        Fortan compiler, version XE 2013 SP1.2.176
                        
aermod_source.zip       AERMOD source code, with batch files to recompile
                        using the Intel Visual Fortran compiler and the 
                        G95 Fortran compiler

aermod_userguide.zip    AERMOD User's Guide (EPA-454/B-03-001) and
                        updated User's Guide Addendum providing user 
                        instructions for features not included in the 
                        original user's guide.

aermod_testcase.zip     AERMOD test cases and associated files, including
                        comparisons of results between AERMOD version 
                        dated 13350 and the previous version dated 12345
